﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data;
using System.Xml.Serialization;
using System.Text.RegularExpressions;
using System.Xml;

namespace EmployeeValidation
{
    public class EmployeeValidator
    {
        /*
        * Do not remove the attached TestProject. It is meant for auto evaluation of your source code.
        * Do not attach any test classess to the attached test project.
        * Do not attach any new test projects.
        * You are not required to write any automated test cases. You are supposed to write only the code.
        */

        public void ProcessData(string xmlFilePath, string xmlFileName, SqlConnection connection)
        {
                      
            EmployeeValidator empVal = new EmployeeValidator();
            List<Employee> lstemp = new List<Employee>();
            lstemp = empVal.ReadAllEmployeesFromXmlFile(xmlFilePath, xmlFileName);

            lstemp = empVal.PickValidEmployees(lstemp);        
    
            empVal.SaveValidEmployeesToDB(lstemp, connection);          

        }
        public List<Employee> ReadAllEmployeesFromXmlFile(string xmlFilePath, string xmlFileName)
        {
            List<Employee> empList = new List<Employee>();
            XElement xelement = XElement.Load(xmlFilePath + xmlFileName);
            IEnumerable<XElement> allEmployees = xelement.Elements();
            
            foreach (var allEmployee in allEmployees)
            {
                empList.Add(new Employee()
                {
                    EmployeeId = allEmployee.Element("EmployeeId").Value,
                    EmployeeName = allEmployee.Element("EmployeeName").Value,
                    EmailId = allEmployee.Element("EmailId").Value,                   
                    DateOfJoining = allEmployee.Element("DateOfJoining").Value
                });               
            }
            return empList;
        }

        public List<Employee> PickValidEmployees(List<Employee> employees)
        {
            List<Employee> empList = new List<Employee>();
            Regex IsNumeric = new Regex(@"^\D+$");
            Regex IsAlphaNumeric = new Regex(@"\W+$");
            Regex IsvalidEmail = new Regex(@"^(?("")(""[^""]+?""@)|(([0-9a-z]((\.(?!\.))|[-!#\$%&'\*\+/=\?\^`\{\}\|~\w])*)(?<=[0-9a-z])@))(?(\[)(\[(\d{1,3}\.){3}\d{1,3}\])|(([0-9a-z][-\w]*[0-9a-z]*\.)+[a-z0-9]{2,17}))$");

            empList = employees.Select(x => employees.Find(
                m => m.EmployeeName != null && m.EmployeeName != string.Empty
                    && !IsNumeric.IsMatch(m.EmployeeId.ToString()) && !IsAlphaNumeric.IsMatch(m.EmployeeName)
                     )).Distinct().ToList();

            return empList;
        }

        public void SaveValidEmployeesToDB(List<Employee> employees, SqlConnection connection)
        {
            string query = @"Insert into SBA.Employees(EmployeeId,EmployeeName,DateOfJoining,EmailId) 
                                            Values(@EmployeeId,@EmployeeName,@DateOfJoining,@EmailId)";
            connection.Open();
            using (SqlCommand cmd = new SqlCommand(query, connection))
            {
                foreach (Employee emp in employees)
                {
                    cmd.Parameters.AddWithValue("@EmployeeId", emp.EmployeeId);
                    cmd.Parameters.AddWithValue("@EmployeeName", emp.EmployeeName);
                    cmd.Parameters.AddWithValue("@EmailId", emp.EmailId);
                    cmd.Parameters.AddWithValue("@DateOfJoining", emp.DateOfJoining);                    
                    int i = cmd.ExecuteNonQuery();
                }
            }
            connection.Close();
        }
    }
}
