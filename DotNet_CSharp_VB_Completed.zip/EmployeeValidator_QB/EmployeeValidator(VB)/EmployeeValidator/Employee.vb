﻿
Public Class Employee
    'Do not modify the return types of the below properties

    'Do not modify this class
    'Do not add new constructors

    Public Property EmployeeId() As String
        Get
            Return m_EmployeeId
        End Get
        Set(ByVal value As String)
            m_EmployeeId = value
        End Set
    End Property
    Private m_EmployeeId As String
    Public Property EmployeeName() As String
        Get
            Return m_EmployeeName
        End Get
        Set(ByVal value As String)
            m_EmployeeName = value
        End Set
    End Property
    Private m_EmployeeName As String
    Public Property EmailId() As String
        Get
            Return m_EmailId
        End Get
        Set(ByVal value As String)
            m_EmailId = value
        End Set
    End Property
    Private m_EmailId As String
    Public Property DateOfJoining() As String
        Get
            Return m_DateOfJoining
        End Get
        Set(ByVal value As String)
            m_DateOfJoining = value
        End Set
    End Property
    Private m_DateOfJoining As String

End Class
