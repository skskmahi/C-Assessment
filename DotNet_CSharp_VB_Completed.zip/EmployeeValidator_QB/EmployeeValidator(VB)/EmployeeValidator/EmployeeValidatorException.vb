﻿Public Class EmployeeValidatorException
    Inherits Exception
End Class
