﻿Imports System.Collections.Generic
Imports System.Data.SqlClient
Imports System.Linq



Module Module1
    'Pass the file path, file names and connection string if any in this method alone. 
    'Do not hardcode in any other methods
    Sub Main()
        Dim connection As New SqlConnection("Data Source=PCName\\SQLEXPRESS;Initial Catalog=DBEmployeeValidation;Integrated Security=True")
        Dim empValidator As New EmployeeValidator()
        empValidator.ProcessData("D:\Dotnetcaassessment\EmployeeValidator\Input File\", "Emp_122014.xml", connection)

    End Sub

End Module
