﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmployeeValidation
{
   
    public class EmployeeValidatorException : Exception
    {
        public EmployeeValidatorException()
            : base()
        {

        }

        public EmployeeValidatorException(string message)
            : base(message)
        {

        }
    }
}
