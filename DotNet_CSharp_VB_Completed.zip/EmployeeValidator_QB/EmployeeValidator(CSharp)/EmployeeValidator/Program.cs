﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;

namespace EmployeeValidation
{
    public class Program
    {
        public static void Main()
        {
              /*
               * Pass the file path, file names and connection string if any in this method alone. 
               * Do not hardcode in any other methods
               */
            SqlConnection connection = new SqlConnection(@"Data Source=PCName\\SQLEXPRESS;Initial Catalog=DBEmployeeValidation;Integrated Security=True");
            EmployeeValidator empValidator = new EmployeeValidator();
            empValidator.ProcessData(@"D:\Dotnetcaassessment\EmployeeValidator\Input File\", "Emp_122014.xml", connection);
                       
        }
    }
}

